#include "MyClass.h"
using namespace std;

MyClass::MyClass(int i):value(i)
{}

int MyClass::getValue()
{
  return value;
}

void MyClass::multiply(int i)
{
  value *= i;
}

void MyClass::add(int i)
{
  value += i;
}

