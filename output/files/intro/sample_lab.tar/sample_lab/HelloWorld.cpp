#include<iostream>
#include "MyClass.h"
using namespace std;

int main(int argc, char *argv[])
{
  //create a MyClass object with 10 for its instance variable value
MyClass jclass(10);
  //call the MyClass object's getValue method and output the result to cout
cout << jclass.getValue() << endl;
  //call the MyClass object's multiply method and pass 2 as the parameter
jclass.multiply(2);
  //call the MyClass object's getValue method and output the result to cout
cout << jclass.getValue() << endl;
  //call the MyClass object's add method and pass 34  as the parameter
jclass.add(34);
  //call the MyClass object's getValue method and output the result to cout
cout << jclass.getValue() << endl;
  return 0;
}

