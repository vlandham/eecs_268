class MyClass
{
  public:
    MyClass(int i);
    void add(int i);
    int getValue();
    void multiply(int i);
  private:
    int value;
 };

