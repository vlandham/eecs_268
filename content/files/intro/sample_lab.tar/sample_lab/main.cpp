/**
 * @file main.cpp
 *
 * @author [Your Name]
 * @date [Today's Date]
 * @version 1.0
 */
#include <iostream>
#include "NamedArray.h"
using namespace std;

int main(int argc, char *argv[])
{
  //create a NamedArray object with 10 for its size, and a name
NamedArray anArray(5, "High Five");

// print array
anArray.printArray();

  //call the NamedArray object's getValue method and output the result to cout
cout << anArray.getValue(3) << endl;

  //call the NamedArray object's getValue method  with invalid value and output the result to cout
cout << anArray.getValue(99) << endl;


  return 0;
}

