#include <iostream>
#include <fstream>

using namespace std;

void str_reverse(char str[], int length);
int str_length(char str[]);
// void str_reverse_iter(char str[], int length);
// int str_length_iter(char str[]);
// int str_compare(char str1[], char str2[]);
// int str_compare_iter(char str1[], char str2[]);
// bool str_replace_first(char str[], char find[], char replace[], bool is_partial_match = false);
// bool str_replace_first_iter(char str[], char find[], char replace[]);

int main(int argc, char* argv[])
{
  char string1[100];
	
	// Confirm command-line parameters
	if (argc < 3)
	{
		cerr << "Error - Expected usage: ./main input.txt output.txt" << endl;
		return 1;
	}
	
	// Initialize file streams
	ifstream in(argv[1]);
	ofstream out(argv[2]);
	
	// Process commands
	while (in >> string1)
	{
      int len = str_length(string1);
			str_reverse(string1, len);
			out << string1 << endl;
      cout << string1 << endl;
	}
	
	return 0;
}

// Recursive String Reverse
void str_reverse(char str[], int length)
{
	// Base case: String too short to reverse
	if (length <= 1)
	{
		return;
	}
	// Recursive case:
	else
	{
		char temp = str[0];
		str[0] = str[length - 1];
		str[length - 1] = temp;
		
		str_reverse(++str, length - 2);
	}
}

// Recursive String Length
int str_length(char str[])
{
	// Base case: End of string
	if (str[0] == '\0')
	{ 
		return 0;
	}
	// Recursive case:
	else
	{
		return 1 + str_length(++str);
	}
}


/*
// Iterative String Reverse
void str_reverse_iter(char str[], int length)
{	
	for (int i = 0; i < length / 2; ++i)
	{
		char temp = str[i];
		str[i] = str[length - i - 1];
		str[length - i - 1] = temp;
	}
}

// Iterative String Length
int str_length_iter(char str[])
{
	int length = 0;
	
	while (str[length] != '\0')
	{
		++length;
	}
	
	return length;
}

// Recursive String Compare
int str_compare(char str1[], char str2[])
{
	// Base case 1: Unequal strings
	if (str1[0] != str2[0])
	{
		return str1[0] - str2[0];
	}
	// Base case 2: Equal strings
	else if (str1[0] == '\0')
	{
		return 0;
	}
	// Recursive case:
	else
	{
		return str_compare(++str1, ++str2);
	}
}

// Iterative String Compare
int str_compare_iter(char str1[], char str2[])
{
	int i;
	
	for (i = 0; str1[i] == str2[i]; ++i)
	{
		if (str1[i] == '\0' || str2[i] == '\0')
		{
			break;
		}
	}
	
	if (str1[i] == str2[i]) 
	{
		return 0;
	}
	else 
	{
		return str1[i] - str2[i];
	}
}

// Recursive String Replace First
bool str_replace_first(char str[], char find[], char replace[], bool is_partial_match)
{
	// Preconditions: str_length(find) == str_length(replace)
	if (str_length(find) != str_length(replace))
	{
		cerr << "Error: Find string length does not match replace string length." << endl;
		return false;
	}
	
	// Base case 1: Finished replacing string
	if (find[0] == '\0')
	{
		return true;
	}
	// Base case 2: Finishing searching string
	else if (str[0] == '\0')
	{
		return false;
	}
	// Recursive case 1:
	else if(str[0] == find[0])
	{
		if (str_replace_first(&str[1], &find[1], &replace[1], true))
		{
			str[0] = replace[0];
			return true;
		}
	}
	
	if (is_partial_match)
	{
		return false;
	}
	// Recursive case 2:
	else 
	{
		return str_replace_first(++str, find, replace, false);
	}
}

// Iterative String Replace First
bool str_replace_first_iter(char str[], char find[], char replace[])
{
	// Preconditions: str_length(find) == str_length(replace)
	if (str_length(find) != str_length(replace))
	{
		cerr << "Error: Find string length does not match replace string length." << endl;
		return false;
	}
	
	int i, j;
	
	for (i = 0; str[i] != '\0'; ++i)
	{
		for (j = 0; find[j] != '\0'; ++j)
		{
			if (str[i + j] != find[j])
			{
				break;
			}
		}
		
		if (find[j] == '\0')
		{
			for (j = 0; find[j] != '\0'; ++j)
			{
				str[i + j] = replace[j];
			}
			
			return true;
		}
	}
	
	return false;
}
*/